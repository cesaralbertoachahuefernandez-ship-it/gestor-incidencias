
# Gestor de Incidencias - Docker Compose

## Descripción del proyecto

Este proyecto consiste en desplegar una aplicación web para gestionar incidencias informáticas utilizando Docker Compose.

La arquitectura está formada por tres servicios:

- Frontend: interfaz gráfica de la aplicación.
- Backend: API que comunica el frontend con la base de datos.
- PostgreSQL: base de datos donde se almacenan las incidencias.

También se utilizan dos redes para separar las comunicaciones y un volumen para mantener los datos guardados.

## Preguntas de la práctica

### 1. ¿Por qué el frontend no necesita conectarse a PostgreSQL?

Porque el frontend solamente se encarga de mostrar la información al usuario. Las consultas y modificaciones de los datos las realiza el backend mediante la API, que es el encargado de comunicarse con PostgreSQL.

### 2. ¿Por qué el backend pertenece a dos redes?

Porque necesita comunicarse tanto con el frontend como con PostgreSQL. Por eso está conectado a las redes frontend y datos.

### 3. ¿Qué servicio necesita publicar un puerto en el anfitrión?

El frontend, porque necesitamos acceder a la aplicación desde nuestro navegador. En este caso utilizamos el puerto 8080.

### 4. ¿Por qué publicar PostgreSQL hacia fuera no es la solución adecuada para un fallo de comunicación interno?

Porque los servicios pueden comunicarse entre ellos utilizando las redes internas de Docker. Publicar PostgreSQL hacia fuera no soluciona un problema de configuración de las redes y además puede suponer un riesgo de seguridad.

### 5. ¿Qué ventaja ofrece Docker Compose respecto a ejecutar los tres contenedores manualmente?

Permite configurar y administrar todos los contenedores desde un único archivo. Así es más fácil iniciar, detener y modificar los servicios sin tener que ejecutar muchos comandos diferentes.

### 6. ¿Por qué hemos dividido la arquitectura en dos redes?

Para separar las comunicaciones de la aplicación. La red frontend conecta el frontend con el backend y la red datos conecta el backend con PostgreSQL. De esta forma mejoramos el aislamiento y la seguridad.

### 7. ¿Por qué el backend utiliza db como dirección de PostgreSQL?

Porque Docker Compose permite que los servicios se comuniquen utilizando sus nombres. En este caso, db es el nombre del servicio de PostgreSQL y Docker se encarga de resolver su dirección IP.

### 8. ¿Qué diferencia existe entre detener un proyecto y eliminar sus volúmenes?

Al detener el proyecto o eliminar sus contenedores con docker compose down, los datos del volumen se conservan. Sin embargo, al utilizar docker compose down -v también se elimina el volumen y se pueden perder los datos almacenados.

### 9. ¿Qué consecuencias tendría para la empresa perder el volumen de PostgreSQL?

La empresa perdería la información almacenada en la base de datos, incluyendo las incidencias registradas. Esto podría provocar problemas en el trabajo diario y la pérdida de información importante para los clientes.
